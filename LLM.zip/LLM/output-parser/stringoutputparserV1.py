from  langchain_huggingface import ChatHuggingFace,HuggingFaceEndpoint
from langchain_core.prompts import PromptTemplate
from langchain_openai import ChatOpenAI
from langchain_core.output_parsers import StrOutputParser

import os 
HUGGING_API_KEY="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"
OPENAI_API_KEY="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"

## Langmith tracking
LANGCHAIN_TRACING_V2="true"
LANGCHAIN_API_KEY='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'


#os.environ["HUGGINGFACEHUB_API_TOKEN"]=HUGGING_API_KEY
os.environ["OPENAI_API_KEY"]=OPENAI_API_KEY
## Langmith tracking
os.environ["LANGCHAIN_TRACING_V2"]="true"
os.environ["LANGCHAIN_API_KEY"]=LANGCHAIN_API_KEY
model =ChatOpenAI()


#model = ChatHuggingFace(llm=llm)
prompt =PromptTemplate(template ="write a detailed report on {topic}",
                       input_variables=['topic'])
prompt2 =PromptTemplate(template ="write a 1 lines summary on the following text : {text}",
                       input_variables=['text'])
parser =StrOutputParser()
chain =prompt|model|parser|prompt2|model|parser
result=chain.invoke({"topic":"blackhole"})
print (result)