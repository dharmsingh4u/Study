from langchain_openai import ChatOpenAI
from langchain_core.messages import SystemMessage, HumanMessage, AIMessage
import os 
OPENAI_API_KEY="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"
## Langmith tracking
LANGCHAIN_TRACING_V2="true"
LANGCHAIN_API_KEY='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'

os.environ["OPENAI_API_KEY"]=OPENAI_API_KEY
## Langmith tracking
os.environ["LANGCHAIN_TRACING_V2"]="true"
os.environ["LANGCHAIN_API_KEY"]=LANGCHAIN_API_KEY
llm=ChatOpenAI(model="gpt-3.5-turbo")
chat_history=[]
messages=[SystemMessage(content='you are AI assistant')]
while True:
    input_message=input("You: ")
    #chat_history.append(input_message)
    messages.append(HumanMessage(content =input_message))
    if input_message == 'exit':   
        break
    else:
        #result=llm.invoke(chat_history) this was normal because in history you cannot find who messages or what
        result=llm.invoke(messages) 
        messages.append(AIMessage(content=result.content) )
        print (result.content)
print(messages)

