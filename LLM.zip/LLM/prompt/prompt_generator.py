from langchain_core.prompts import PromptTemplate
import os
OPENAI_API_KEY="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"
## Langmith tracking
LANGCHAIN_TRACING_V2="true"
LANGCHAIN_API_KEY='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'

#os.environ["OPENAI_API_KEY"]=OPENAI_API_KEY
## Langmith tracking
os.environ["LANGCHAIN_TRACING_V2"]="true"
os.environ["LANGCHAIN_API_KEY"]=LANGCHAIN_API_KEY
template =PromptTemplate(template ="""Please summarize the research paper titled \"{paper_input}\" with the following specifications:\nExplanation Style: {style_input}  \nExplanation Length: {length_input}  \n1. Mathematical Details:  \n   - Include relevant mathematical equations if present in the paper.  \n   - Explain the mathematical concepts using simple, intuitive code snippets where applicable.  \n2. Analogies:  \n   - Use relatable analogies to simplify complex ideas.  \nIf certain information is not available in the paper, respond with: \"Insufficient information available\" instead of guessing.  \nEnsure the summary is clear, accurate, and aligned with the provided style and length.""",
                         input_variables=['paper_input','style_input','length_input'],validate_template=True)
template.save('template.json')