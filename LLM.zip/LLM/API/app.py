
from langchain.prompts import ChatPromptTemplate
from langchain.chat_models import ChatOpenAI
import streamlit as st 
from langserve import add_routes
import uvicorn
from fastapi import FastAPI
import os
OPENAI_API_KEY="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"
## Langmith tracking
LANGCHAIN_TRACING_V2="true"
LANGCHAIN_API_KEY='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'
os.environ["OPENAI_API_KEY"]=OPENAI_API_KEY
## Langmith tracking
os.environ["LANGCHAIN_TRACING_V2"]="true"
os.environ["LANGCHAIN_API_KEY"]=LANGCHAIN_API_KEY

app=FastAPI(
    title="Langchain Server",
    version="1.0",
    decsription="A simple API Server"

)

model=ChatOpenAI()
prompt1=ChatPromptTemplate.from_template("Write me an essay about {topic} with 100 words")
add_routes(
    app,
    prompt1|model,
    path="/essay"


)


if __name__=="__main__":
    uvicorn.run(app, host='127.0.0.1', port=8080)